"""Capped worker; imports occur only after process-tree caps are installed."""
import sys
if __name__ == '__main__' and sys.stdin.readline().strip() != 'GO':
    raise SystemExit('Process caps required')
import json
from pathlib import Path
from time import perf_counter


def main(out):
    source = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(source))
    from omega_v2.testbed.workflow.manifest import verify_bundle, atomic_json
    from omega_v2.testbed.compiler import compile_world
    from omega_v2.testbed.domination_friction import FrictionParameters, FrictionPolicy, build_world, matched_roots
    from omega_v2.testbed.analysis.expanded_friction_profile import profile
    config = verify_bundle(out)['config']
    start = perf_counter()
    progress = lambda stage: print(json.dumps({'stage': stage, 'seconds': perf_counter()-start}), flush=True)
    parameters = FrictionParameters(**config['parameters'])
    world = build_world(parameters, FrictionPolicy(**config['policy']), max_states=32000)
    compiled = compile_world(world, max_states=32000)
    progress('compiled')
    imports = {k: str(Path(v.__file__).resolve()) for k, v in sys.modules.items()
               if k.startswith('omega_v2') and getattr(v, '__file__', None)}
    if any(not Path(x).is_relative_to(source) for x in imports.values()):
        raise RuntimeError('Source escaped immutable snapshot')
    result = profile(world, compiled, {'device_present': matched_roots(parameters)['device_present']},
                     config['cadences'], config['horizons'], config.get('block_rows', 32), progress)
    result.update(case=config['id'], total_seconds=perf_counter()-start,
                  imported_source_paths=imports, imports_from_snapshot=True)
    atomic_json(out/'RESULTS.json', result)
    progress('complete')

if __name__ == '__main__':
    main(Path(sys.argv[1]))
